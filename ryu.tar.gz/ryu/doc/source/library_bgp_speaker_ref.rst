*********************************
BGP speaker library API Reference
*********************************

BGPSpeaker class
================

.. autoclass:: ryu.services.protocols.bgp.bgpspeaker.BGPSpeaker
   :members:

.. autoclass:: ryu.services.protocols.bgp.bgpspeaker.EventPrefix
   :members:

.. autoclass:: ryu.services.protocols.bgp.info_base.base.PrefixFilter
   :members:

.. autoclass:: ryu.services.protocols.bgp.info_base.base.ASPathFilter
   :members:

.. autoclass:: ryu.services.protocols.bgp.info_base.base.AttributeMap
   :members:
